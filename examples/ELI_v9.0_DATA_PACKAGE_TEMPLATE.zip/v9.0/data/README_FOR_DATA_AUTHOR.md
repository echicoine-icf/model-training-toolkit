# ELI v9.0 data package — authoring template

This skeleton intentionally contains NO training examples or system prompt. The author MUST supply reviewed real training data, a matching system prompt, and independent evaluation cases. See `docs/DATA_PACKAGE_CONTRACT.md` in the Model Training Toolkit release.

Required file names, all in this folder:
- `train.jsonl` — each line `{ "id": "...", "question": "...", "expected": {...} }`
- `system_prompt.txt` — the exact model system message, no silent templating

Optional but expected for evaluation:
- `eval.jsonl` — independent frozen tests, same format
- `schema.json` — if prompt assembly requires it or for documentation

`prompt_assembly=prompt_only` means do NOT append `schema.json` automatically; only use `append_schema` if the team has validated that convention.

Do not pack an already fine-tuned checkpoint or training script into a data package. Those belong to the toolkit's run and export lifecycle.
